package Threads;

public class Bank {
	private int balance=0;

	public  int getBalance() {
		return balance;
	}

	public  void setBalance(int balance) {
		this.balance  = balance;
	}

}
