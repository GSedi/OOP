
import java.util.*;

public class Executor extends Employee {

	private Vector<Order> order;
	
	private Vector<Order> doneorder;
	
	public Executor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Executor(int salary) {
		super(salary);
		// TODO Auto-generated constructor stub
	}

	public Executor(String id, String password, String name, String surname, int salary) {
		super(id, password, name, surname, salary);
		// TODO Auto-generated constructor stub
	}

	public int compareTo(Object other) {
	    return super.compareTo(other);
	}
	
	public String toString() {
	    return super.toString();
	}
	
	public int hashCode() {
	    return Objects.hash(this);
	}
	
	public User clone() throws CloneNotSupportedException {
	    Executor cloned = (Executor) super.clone();
		return cloned;
	}
	
	public boolean equals(Object a) {
		Executor aa = (Executor) a;
	    return Objects.equals(this, aa);
	}
	
	public void setSalary(int salary) {
		super.setSalary(salary * order.size());;
	}
	
	
	
	public void acceptOrder(Order a) {
		order.addElement(a);
	}
	
	public void doneOrder(Order a) {
		doneorder.addElement(a);
	}
	
	public void rejectOrder(Order a) {
		order.removeElement(a);
	}
	
	public Vector<Order> viewOrders() {
		return order;
	}
	
	public Vector<Order> viewDoneOrders() {
		return doneorder;
	}
}

