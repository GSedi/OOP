import java.util.*;
import java.lang.*;
import java.io.*;
public class Driver {
	
	public static void save() throws IOException, ClassNotFoundException{
		Database.serUsers();
		Database.serSpecialities();
		Database.serStudents();
	}
	public static void deserializeObjects() throws IOException, ClassNotFoundException{
		if(new File("users.ser").exists()) Database.desUsers();
		if(new File("specialities.ser").exists()) Database.desSpecialities();
		if(new File("students.ser").exists()) Database.desStudents();
	}

	public static void main(String[] args) throws CloneNotSupportedException, ClassNotFoundException {
		String inputId, inputPassword, inputName, inputSurname, inputSpeciality, inputDegree;
		String line, id, password, position;
		String currentInput;
		String choice;
		int inputYearOfStudy, index = 1;
		
		boolean idCheck = false, passwordCheck = false;
		try {
			deserializeObjects();
			BufferedReader br = new BufferedReader(new FileReader("base.txt"));
			BufferedWriter bw = new BufferedWriter(new FileWriter("base.txt", true));
			//\Scanner in = new Scanner(System.in);
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			StringTokenizer token;
			User user = null;
			Degree degree;
			
			/*Admin a = new Admin("16AD00001", "admin", "Admin", "Adminov", 400000);
			Database.users.add(a);
			Speciality spec = new Speciality("IS", "5B070300");
			Database.specialities.add(spec);
			/*Database.users.clear();
			Database.specialities.clear();
			Database.students.clear();
			*/
			
			
			System.out.println("Welcome!");
			main : while(true) {
						System.out.println("Enter your id and password else '0' to exit");
						inputId = in.readLine();
//						System.out.println(Database.users.get(0).getId());
						if(inputId.equals("0")) {
							System.out.println("Goodbye!");
							
							break;
						}
						else {
							inputPassword = in.readLine();
							for(User u : Database.users) {
								System.out.println(u.toString());
								if((u.getId()).equals(inputId)){
									idCheck = true;
									if((u.getPassword()).equals(inputPassword)) {
										passwordCheck = true;
										user = u;
									}
								}
							}
							
							
							
							if(idCheck) {
								if(passwordCheck) {
									System.out.println("Hello, " + user.getName());
									if(user instanceof Admin) {
										admin : while(true) {
													System.out.println("What do you want to do?");
													System.out.println("\n 1) Add User \n 2) Update User \n 3) Remove User \n 4) Add order for Executor\n  5) Return back \n 6) Exit");
													
													choice = in.readLine();
													if(choice.equals("1")) {
														
														System.out.println("What type of User you want to add?");
														System.out.println("\n 1) Student \n 2) Teacher \n 3) Manager \n 4) Executor \n 5) Admin");
															choice = in.readLine();
															if(choice.equals("1")) {
																System.out.println("Enter information about Student");
																System.out.println("Enter name, surname, student id, set password, degree, year of study and speciality");
																inputName = in.readLine();
																inputSurname = in.readLine();
																inputId = in.readLine();
																inputPassword = in.readLine();
																//inputDegree = in.readLine();
																System.out.println("Choose degree");
																
																for(Degree value: Degree.values()){
																    System.out.println("\n" + index+ ") " + value.name());
																    index++;
																}
																inputDegree = in.readLine();
																degree  = Degree.values()[Integer.parseInt(inputDegree)];
																inputYearOfStudy = Integer.parseInt(in.readLine());
															
																System.out.println("Choose Speciality");
																for(int i = 0; i < Database.specialities.size(); i++) {
																	System.out.println(i + 1 + Database.specialities.get(i).toString());
																}
																choice = in.readLine();
																Speciality speciality = (Speciality)Database.specialities.get(Integer.parseInt(choice)-1).clone();
																((Admin) user).addUser(new Student(inputName, inputSurname, inputId, inputPassword, degree, inputYearOfStudy, speciality));
																Database.students.add(new Student(inputName, inputSurname, inputId, inputPassword, degree, inputYearOfStudy, speciality));
																
															}
															
													}
													else if(choice.equals("2")) {
														System.out.println("Choose User");
														for(int i = 0; i < Database.users.size(); i++) {
															System.out.println(i+1 + Database.users.get(i).toString());
														}
														choice = in.readLine();
														System.out.println( Database.users.get(Integer.parseInt(choice)-1).toString());
														User userUpdate = Database.users.get(Integer.parseInt(choice)-1);
														boolean v = true;
														while(v){
															System.out.println("\n 1) Change name\n 2) Change surname\n 3) Change id\n 4) reset password\n 5) quit");
															choice = in.readLine();
															if(choice.equals("1")){
																System.out.println("Enter name");
																inputName = in.readLine();
																userUpdate.setName(inputName);	
															}
															
															else if(choice.equals("2")){
																System.out.println("Enter surname");
																inputSurname = in.readLine();
																userUpdate.setSurname(inputSurname);	
															}
															
															else if(choice.equals("3")){
																System.out.println("Enter Id");
																inputId = in.readLine();
																userUpdate.setId(inputId);	
															}
															
															else if(choice.equals("4")){
																userUpdate.setPassword("kbtu123");	
															}
															
															else if(choice.equals("5")){
																v = false; 	
															}
														}
													}
													else if(choice.equals("3")) {
														System.out.println("Choose User");
														for(int i = 0; i < Database.users.size(); i++) {
															System.out.println(i+1 + Database.users.get(i).toString());
														}
														choice = in.readLine();
														System.out.println( Database.users.get(Integer.parseInt(choice)-1).toString());
														((Admin) user).removeUser(Database.users.get(Integer.parseInt(choice)-1));
													}
													else if(choice.equals("4")) {
														
													}
													else if(choice.equals("5")) continue main;
													else {
														System.out.println("Goodbye!");
														break main;
													}
												}
										
									}
								}
								else {
									System.out.println("Wrong password!!!");
									continue main;
								}
							}
							else {
								System.out.println("Wrong ID!!!");
								continue main;
							}
							
							
						}
					}
			save();	
			bw.close();
			br.close();
		}
		catch(FileNotFoundException fe) {
            System.out.println("File not found");
		} catch(IOException ioe) {
			ioe.printStackTrace();
            System.out.println("Can�t read from file");
		}
		

	}

}

/*br = new BufferedReader(new FileReader("base.txt"));
 * while((line = br.readLine()) != null) {

if(line.contains(inputId)) {
	token = new StringTokenizer(line, " ", false);
	id = token.nextToken();
	password = token.nextToken();
	position = token.nextToken();

	if(password.equals(inputPassword)) {
		ok = true;
		System.out.println("You have signed in as " + position);

if(position.equals("Admin")) {

}
}
else {

ok = true;
System.out.println("Wrong password!");
break;
}

}


}

if(!ok) {
System.out.println("Wrong id");
}*/
