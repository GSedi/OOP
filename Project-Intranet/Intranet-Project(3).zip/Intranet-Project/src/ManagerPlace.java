
import java.io.Serializable;
import java.util.*;
/**
*/
public enum ManagerPlace implements Serializable {
/**
*/
		OR_MANAGER, DEPARTMENT_MANAGER;
}

