
import java.util.*;
import java.lang.*;

public class Order extends Text {
	
	public Order() {
		super();
	}
	
	public Order(String orderTitle, String orderText) {
		super(orderTitle, orderText);
	}
	
	public Order(String orderTitle) {
		super(orderTitle);
	}
}

