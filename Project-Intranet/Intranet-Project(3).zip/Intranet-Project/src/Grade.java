import java.io.Serializable;

/**
*/
public enum Grade implements Serializable {
	A, B, C, D, F, A_MINUS,B_PLUS, B_MINUS, C_PLUS,C_MINUS, D_PLUS, D_MINUS, PASS, NOT_PASS; 
	
}